function [size1,rotation,incr,s]=inputart()
size1=input('Enter The Size Of Image (For Ex : 128) :')
rotation=input('Enter The Rotation Up To From 0 Degree To (For Ex: 0,45,90,135,170 and 180) :')
incr=input('Enter The Incrementing Value Of THETA (For Ex: 10,45 and 90):')
s=input('Enter The Number Of Iteration (For Ex: 8):')
end